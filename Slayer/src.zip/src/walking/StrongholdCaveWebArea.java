package walking;

import org.tbot.methods.web.Web;
import org.tbot.methods.web.actions.ObjectAction;
import org.tbot.methods.web.areas.WebArea;
import org.tbot.methods.web.nodes.WebNode;
import org.tbot.wrappers.Tile;

/**
 * Created by Russell on 3/8/2016.
 */
public class StrongholdCaveWebArea extends WebArea {
    @Override
    public void addTo(Web web) {
        WebNode startNode = web.getNearestWebNode(new Tile(2430,3424,0));
        ObjectAction ObjectAction0 = new ObjectAction(new Tile(2428,3423,0), "Cave", "Enter");
        ObjectAction ObjectAction1 = new ObjectAction(new Tile(2428,3424,0), "Cave", "Enter");
        ObjectAction ObjectAction2 = new ObjectAction(new Tile(2428,3425,0), "Cave", "Enter");
        ObjectAction ObjectAction3 = new ObjectAction(new Tile(2429,3423,0), "Cave", "Enter");
        ObjectAction ObjectAction4 = new ObjectAction(new Tile(2429,3424,0), "Cave", "Enter");
        ObjectAction ObjectAction5 = new ObjectAction(new Tile(2429,3425,0), "Cave", "Enter");
        WebNode node0 = web.getNode(new Tile(2444,9825,0));
        WebNode node1 = web.getNode(new Tile(2439,9812,0));
        WebNode node2 = web.getNode(new Tile(2439,9797,0));
        WebNode node3 = web.getNode(new Tile(2430,9788,0));
        WebNode node4 = web.getNode(new Tile(2416,9785,0));
        WebNode node5 = web.getNode(new Tile(2405,9786,0));
        WebNode node6 = web.getNode(new Tile(2414,9777,0));
        WebNode node7 = web.getNode(new Tile(2393,9788,0));
        ObjectAction ObjectAction6 = new ObjectAction(new Tile(2392,9788,0), "Roots", "Chop");
        WebNode node8 = web.getNode(new Tile(2391,9788,0));
        WebNode node9 = web.getNode(new Tile(2377,9785,0));
        WebNode node10 = web.getNode(new Tile(2365,9781,0));
        WebNode node11 = web.getNode(new Tile(2364,9767,0));
        WebNode node12 = web.getNode(new Tile(2370,9757,0));
        WebNode node13 = web.getNode(new Tile(2374,9744,0));
        WebNode node14 = web.getNode(new Tile(2378,9738,0));
        ObjectAction ObjectAction7 = new ObjectAction(new Tile(2379,9738,0), "Root", "Step-over");
        WebNode node15 = web.getNode(new Tile(2380,9738,0));
        WebNode node16 = web.getNode(new Tile(2386,9746,0));

    }
}
